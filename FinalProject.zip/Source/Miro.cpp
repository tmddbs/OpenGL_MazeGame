#include "Maze.h"

void BMPtoTexture(void) {  // BMP������ �ؽ��ķ� ����� �Լ�

    unsigned char* image = NULL;
    image = Read_BmpImage(tfname.c_str(), &textureWidth, &textureHeight, &textureComponents);

    glEnable(GL_TEXTURE_2D);
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, textureWidth, textureHeight, 0,
        GL_RGB, GL_UNSIGNED_BYTE, image);

    free(image);

}




const int mazeSize = 20;  // �̷� ũ�⸦ ���ϴ� ����

int maze[mazeSize][mazeSize] = {       // �̷��� ����
{1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,1},
{1,0,0,1,1,0,1,1,0,1,0,1,0,1,0,1,1,1,0,1},
{1,0,0,1,1,0,0,0,0,1,0,1,0,1,0,0,0,0,0,1},
{1,0,0,1,1,1,1,1,1,1,0,1,0,1,0,1,1,1,1,1},
{1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1},
{1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,0,1},
{1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
{1,0,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{1,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1},
{1,0,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1},
{1,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,1},
{1,0,1,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1},
{1,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1},
{1,0,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,0,1},
{1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1},
{1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,0,1,0,1},
{1,0,1,0,0,0,0,1,0,0,0,1,0,1,0,1,1,1,1,1},
{1,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}


};


void drawMinimap() {

    GLint originalMatrixMode;
    GLboolean isDepthTestEnabled;
    glGetIntegerv(GL_MATRIX_MODE, &originalMatrixMode);
    isDepthTestEnabled = glIsEnabled(GL_DEPTH_TEST);

    // �̴ϸ� ����Ʈ ����
    glViewport(glutGet(GLUT_WINDOW_WIDTH) * minimapX, glutGet(GLUT_WINDOW_HEIGHT) * minimapY,
        glutGet(GLUT_WINDOW_WIDTH) * minimapSize, glutGet(GLUT_WINDOW_HEIGHT) * minimapSize);

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, mazeSize, 0, mazeSize);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glDisable(GL_DEPTH_TEST);

    // �̴ϸ� �׸���
    for (int i = 0; i < mazeSize; ++i) {
        for (int j = 0; j < mazeSize; ++j) {
            if (maze[i][j] == 1) {
                glColor3f(1.0f, 1.0f, 1.0f);
                glBegin(GL_QUADS);
                glVertex2f(i, j);
                glVertex2f(i + 1, j);
                glVertex2f(i + 1, j + 1);
                glVertex2f(i, j + 1);
                glEnd();
            }
        }
    }
    glColor3f(0.9f, 0.9f, 0.9f);
    glPointSize(5.0f);
    glBegin(GL_POINTS);
    glVertex2f(cameraX, cameraZ);
    glEnd();

    if (isDepthTestEnabled) {
        glEnable(GL_DEPTH_TEST);
    }
    // ���� ����Ʈ�� ����
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    // ���� ������ ����
    glMatrixMode(originalMatrixMode);
    if (isDepthTestEnabled) {
        glEnable(GL_DEPTH_TEST);
    }
}


void ReadModel() {

    FILE* f1;      char s[81];         int i;
    if (mpoint != NULL) delete mpoint;
    if (mface != NULL) delete mface;

    if ((f1 = fopen(fname.c_str(), "rt")) == NULL) { printf("No file\n"); exit(0); }
    fscanf(f1, "%s", s);    fscanf(f1, "%s", s);   fscanf(f1, "%d", &pnum);
    mpoint = new Point[pnum];

    for (i = 0; i < pnum; i++) {
        fscanf(f1, "%f", &mpoint[i].x);   fscanf(f1, "%f", &mpoint[i].y); fscanf(f1, "%f", &mpoint[i].z);
    }

    fscanf(f1, "%s", s);
    fscanf(f1, "%s", s);
    fscanf(f1, "%d", &fnum);

    mface = new Face[fnum];
    for (i = 0; i < fnum; i++) {
        fscanf(f1, "%d", &mface[i].ip[0]);   fscanf(f1, "%d", &mface[i].ip[1]);  fscanf(f1, "%d", &mface[i].ip[2]);
    }
    fclose(f1);
}
void drawModel() {
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);

    glTranslatef(mazeSize / 2.0f, 0.4f, mazeSize / 2.0f);

    glEnable(GL_LIGHT0);
    for (int i = 0; i < fnum; i++) {
        glBegin(GL_TRIANGLES);

        Point v1 = mpoint[mface[i].ip[0]];
        Point v2 = mpoint[mface[i].ip[1]];
        Point v3 = mpoint[mface[i].ip[2]];
        Point normal = {
            (v2.y - v1.y) * (v3.z - v1.z) - (v2.z - v1.z) * (v3.y - v1.y),
            (v2.z - v1.z) * (v3.x - v1.x) - (v2.x - v1.x) * (v3.z - v1.z),
            (v2.x - v1.x) * (v3.y - v1.y) - (v2.y - v1.y) * (v3.x - v1.x)
        };
        GLfloat length = sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
        normal.x /= length;
        normal.y /= length;
        normal.z /= length;
        glNormal3f(normal.x, normal.y, normal.z);

        glVertex3f(v1.x, v1.y, v1.z);
        glVertex3f(v2.x, v2.y, v2.z);
        glVertex3f(v3.x, v3.y, v3.z);

        glEnd();
    }

    glDisable(GL_COLOR_MATERIAL);
}

void ReadModel1() {

    FILE* f1;      char s[81];         int i;
    if (mpoint1 != NULL) delete mpoint1;
    if (mface1 != NULL) delete mface1;

    if ((f1 = fopen(fname1.c_str(), "rt")) == NULL) { printf("No file\n"); exit(0); }
    fscanf(f1, "%s", s);     fscanf(f1, "%s", s);    fscanf(f1, "%d", &pnum1);
    mpoint1 = new Point1[pnum1];

    for (i = 0; i < pnum1; i++) {
        fscanf(f1, "%f", &mpoint1[i].x);   fscanf(f1, "%f", &mpoint1[i].y); fscanf(f1, "%f", &mpoint1[i].z);
    }

    fscanf(f1, "%s", s);
    fscanf(f1, "%s", s);
    fscanf(f1, "%d", &fnum1);

    mface1 = new Face1[fnum1];
    for (i = 0; i < fnum1; i++) {
        fscanf(f1, "%d", &mface1[i].ip[0]);   fscanf(f1, "%d", &mface1[i].ip[1]);  fscanf(f1, "%d", &mface1[i].ip[2]);
    }
    fclose(f1);
}
void drawModel1() {
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);


    glTranslatef(mazeSize / 2.0f, 0.4f, mazeSize / 2.0f);


    for (int i = 0; i < fnum1; i++) {
        glBegin(GL_TRIANGLES);


        Point1 v1 = mpoint1[mface1[i].ip[0]];
        Point1 v2 = mpoint1[mface1[i].ip[1]];
        Point1 v3 = mpoint1[mface1[i].ip[2]];
        Point1 normal = {
            (v2.y - v1.y) * (v3.z - v1.z) - (v2.z - v1.z) * (v3.y - v1.y),
            (v2.z - v1.z) * (v3.x - v1.x) - (v2.x - v1.x) * (v3.z - v1.z),
            (v2.x - v1.x) * (v3.y - v1.y) - (v2.y - v1.y) * (v3.x - v1.x)
        };
        GLfloat length = sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
        normal.x /= length;
        normal.y /= length;
        normal.z /= length;
        glNormal3f(normal.x, normal.y, normal.z);

        glVertex3f(v1.x, v1.y, v1.z);
        glVertex3f(v2.x, v2.y, v2.z);
        glVertex3f(v3.x, v3.y, v3.z);

        glEnd();
    }

    glDisable(GL_COLOR_MATERIAL);
}

void ReadModel2() {

    FILE* f1;      char s[81];         int i;
    if (mpoint2 != NULL) delete mpoint2;
    if (mface2 != NULL) delete mface2;

    if ((f1 = fopen(fname2.c_str(), "rt")) == NULL) { printf("No file\n"); exit(0); }
    fscanf(f1, "%s", s);    fscanf(f1, "%s", s);       fscanf(f1, "%d", &pnum2);
    mpoint2 = new Point2[pnum2];

    for (i = 0; i < pnum2; i++) {
        fscanf(f1, "%f", &mpoint2[i].x);   fscanf(f1, "%f", &mpoint2[i].y); fscanf(f1, "%f", &mpoint2[i].z);

    }

    fscanf(f1, "%s", s);
    fscanf(f1, "%s", s);
    fscanf(f1, "%d", &fnum2);

    mface2 = new Face2[fnum2];
    for (i = 0; i < fnum2; i++) {
        fscanf(f1, "%d", &mface2[i].ip[0]);   fscanf(f1, "%d", &mface2[i].ip[1]);  fscanf(f1, "%d", &mface2[i].ip[2]);

    }
    fclose(f1);
}
void drawModel2() {
    glEnable(GL_COLOR_MATERIAL);
    glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);


    glTranslatef(mazeSize / 2.0f, 0.4f, mazeSize / 2.0f);


    for (int i = 0; i < fnum2; i++) {
        glBegin(GL_TRIANGLES);

        Point2 v1 = mpoint2[mface2[i].ip[0]];
        Point2 v2 = mpoint2[mface2[i].ip[1]];
        Point2 v3 = mpoint2[mface2[i].ip[2]];
        Point2 normal = {
            (v2.y - v1.y) * (v3.z - v1.z) - (v2.z - v1.z) * (v3.y - v1.y),
            (v2.z - v1.z) * (v3.x - v1.x) - (v2.x - v1.x) * (v3.z - v1.z),
            (v2.x - v1.x) * (v3.y - v1.y) - (v2.y - v1.y) * (v3.x - v1.x)
        };
        GLfloat length = sqrt(normal.x * normal.x + normal.y * normal.y + normal.z * normal.z);
        normal.x /= length;
        normal.y /= length;
        normal.z /= length;
        glNormal3f(normal.x, normal.y, normal.z);

        glVertex3f(v1.x, v1.y, v1.z);
        glVertex3f(v2.x, v2.y, v2.z);
        glVertex3f(v3.x, v3.y, v3.z);

        glEnd();
    }

    glDisable(GL_COLOR_MATERIAL);
}
void drawMaze() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    // ī�޶� ����
    float lookX = cameraX + cos(cameraYaw) * cos(cameraPitch);
    float lookY = cameraY + sin(cameraPitch);
    float lookZ = cameraZ + sin(cameraYaw) * cos(cameraPitch);
    gluLookAt(cameraX, cameraY, cameraZ, lookX, lookY, lookZ, 0, 1, 0);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // �ٴ� �ؽ�ó ������
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f); glVertex3f(0.0f, -0.5f, 0.0f);
    glTexCoord2f(1.0f, 0.0f); glVertex3f(mazeSize, -0.5f, 0.0f);
    glTexCoord2f(1.0f, 1.0f); glVertex3f(mazeSize, -0.5f, mazeSize);
    glTexCoord2f(0.0f, 1.0f); glVertex3f(0.0f, -0.5f, mazeSize);
    glEnd();

    // �̷� �׸���
    for (int i = 0; i < mazeSize; ++i) {
        for (int j = 0; j < mazeSize; ++j) {
            if (maze[i][j] == 1) {
                glEnable(GL_TEXTURE_2D);
                glBindTexture(GL_TEXTURE_2D, textureID);

                glBegin(GL_QUADS);


                glTexCoord2f(0.0f, 0.0f); glVertex3f(i, -0.5f, j);
                glTexCoord2f(1.0f, 0.0f); glVertex3f(i + 1, -0.5f, j);
                glTexCoord2f(1.0f, 1.0f); glVertex3f(i + 1, 2.0f, j);
                glTexCoord2f(0.0f, 1.0f); glVertex3f(i, 2.0f, j);


                glTexCoord2f(0.0f, 0.0f); glVertex3f(i + 1, -0.5f, j + 1);
                glTexCoord2f(1.0f, 0.0f); glVertex3f(i, -0.5f, j + 1);
                glTexCoord2f(1.0f, 1.0f); glVertex3f(i, 2.0f, j + 1);
                glTexCoord2f(0.0f, 1.0f); glVertex3f(i + 1, 2.0f, j + 1);


                glTexCoord2f(0.0f, 0.0f); glVertex3f(i, -0.5f, j);
                glTexCoord2f(1.0f, 0.0f); glVertex3f(i, -0.5f, j + 1);
                glTexCoord2f(1.0f, 1.0f); glVertex3f(i, 2.0f, j + 1);
                glTexCoord2f(0.0f, 1.0f); glVertex3f(i, 2.0f, j);


                glTexCoord2f(0.0f, 0.0f); glVertex3f(i + 1, -0.5f, j);
                glTexCoord2f(1.0f, 0.0f); glVertex3f(i + 1, -0.5f, j + 1);
                glTexCoord2f(1.0f, 1.0f); glVertex3f(i + 1, 2.0f, j + 1);
                glTexCoord2f(0.0f, 1.0f); glVertex3f(i + 1, 2.0f, j);

                glEnd();
                glDisable(GL_TEXTURE_2D);
            }
        }
    }
    if (item) { // �������� �Ծ����� �̴ϸ��� �׸����� ��
        drawMinimap();
    }

    glViewport(0, 0, glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));



    glEnable(GL_LIGHTING);   // ���� ����
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientColor);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseColor);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specularColor);

    // SOR ��1,2,3 ��ġ
    glTranslatef(-8.53264, -0.5, -2.53296);
    drawModel();
    glTranslatef(-1.48003, 0, -7.64256);

    glTranslatef(1.4753, -0.5, -5.41142);
    drawModel1();
    glTranslatef(-11.4753, 0, -4.58858);

    glTranslatef(7.3404, -0.68, -8.43875);
    drawModel2();

    glDisable(GL_TEXTURE_2D);
    glutSwapBuffers();
}

bool isWall(float x, float z) {
    float halfSize = 0.15;  // �浹 ���� ����

    for (int i = -1; i <= 1; ++i) {
        for (int j = -1; j <= 1; ++j) {
            int mazeX = (int)floor(x + i * halfSize);
            int mazeZ = (int)floor(z + j * halfSize);


            if (mazeX >= 0 && mazeX < mazeSize && mazeZ >= 0 && mazeZ < mazeSize) {
                if (maze[mazeX][mazeZ] == 1) {
                    return true;  // �ֺ��� ���� ������ �浹
                }
            }
        }
    }

    return false;  //���� ������ �浹 ����
}
bool checkCameraModelCollision() { // ù��° �� �浹 ����

    float collisionDistance = 0.1f;  // �浹 ����


    Point cameraPosition = { cameraX - -8.53264, cameraY, cameraZ - -2.53296 };

    for (int i = 0; i < fnum; ++i) {
        Point v1 = mpoint[mface[i].ip[0]];
        Point v2 = mpoint[mface[i].ip[1]];
        Point v3 = mpoint[mface[i].ip[2]];


        v1.x += mazeSize / 2.0f;
        v1.z += mazeSize / 2.0f;

        v2.x += mazeSize / 2.0f;
        v2.z += mazeSize / 2.0f;

        v3.x += mazeSize / 2.0f;
        v3.z += mazeSize / 2.0f;


        float distance1 = sqrt(pow(cameraPosition.x - v1.x, 2) + pow(cameraPosition.y - v1.y, 2) + pow(cameraPosition.z - v1.z, 2));
        float distance2 = sqrt(pow(cameraPosition.x - v2.x, 2) + pow(cameraPosition.y - v2.y, 2) + pow(cameraPosition.z - v2.z, 2));
        float distance3 = sqrt(pow(cameraPosition.x - v3.x, 2) + pow(cameraPosition.y - v3.y, 2) + pow(cameraPosition.z - v3.z, 2));

        if (min({ distance1, distance2, distance3 }) < collisionDistance) {
            return true;
        }
    }

    return false;
}
bool checkCameraModelCollision1() { // �ι�° �� �浹 ����

    float collisionDistance = 0.1f;

    Point1 cameraPosition = { cameraX - 1.4753, cameraY, cameraZ + 5.41142 };

    for (int i = 0; i < fnum1; ++i) {
        Point1 v1 = mpoint1[mface[i].ip[0]];
        Point1 v2 = mpoint1[mface[i].ip[1]];
        Point1 v3 = mpoint1[mface[i].ip[2]];

        v1.x += mazeSize / 2.0f;
        v1.z += mazeSize / 2.0f;

        v2.x += mazeSize / 2.0f;
        v2.z += mazeSize / 2.0f;

        v3.x += mazeSize / 2.0f;
        v3.z += mazeSize / 2.0f;

        float distance1 = sqrt(pow(cameraPosition.x - v1.x, 2) + pow(cameraPosition.y - v1.y, 2) + pow(cameraPosition.z - v1.z, 2));
        float distance2 = sqrt(pow(cameraPosition.x - v2.x, 2) + pow(cameraPosition.y - v2.y, 2) + pow(cameraPosition.z - v2.z, 2));
        float distance3 = sqrt(pow(cameraPosition.x - v3.x, 2) + pow(cameraPosition.y - v3.y, 2) + pow(cameraPosition.z - v3.z, 2));

        if (min({ distance1, distance2, distance3 }) < collisionDistance) {
            return true;
        }
    }

    return false;
}
bool checkCameraModelCollision2() { // ����° �� �浹 ����

    float collisionDistance = 0.1f;

    Point2 cameraPosition = { cameraX - 7.5404, cameraY, cameraZ + 8.53875 };

    for (int i = 0; i < fnum2; ++i) {
        Point2 v1 = mpoint2[mface[i].ip[0]];
        Point2 v2 = mpoint2[mface[i].ip[1]];
        Point2 v3 = mpoint2[mface[i].ip[2]];

        v1.x += mazeSize / 2.0f;
        v1.z += mazeSize / 2.0f;

        v2.x += mazeSize / 2.0f;
        v2.z += mazeSize / 2.0f;

        v3.x += mazeSize / 2.0f;
        v3.z += mazeSize / 2.0f;

        float distance1 = sqrt(pow(cameraPosition.x - v1.x, 2) + pow(cameraPosition.y - v1.y, 2) + pow(cameraPosition.z - v1.z, 2));
        float distance2 = sqrt(pow(cameraPosition.x - v2.x, 2) + pow(cameraPosition.y - v2.y, 2) + pow(cameraPosition.z - v2.z, 2));
        float distance3 = sqrt(pow(cameraPosition.x - v3.x, 2) + pow(cameraPosition.y - v3.y, 2) + pow(cameraPosition.z - v3.z, 2));

        if (min({ distance1, distance2, distance3 }) < collisionDistance) {
            return true;
        }
    }

    return false;
}

bool keyStates[256] = { false }; // Ű ���¸� �����ϴ� �迭

// Ű�� ������ ��
void handleKeypress(unsigned char key, int x, int y) {
    keyStates[key] = true; // Ű�� ���¸� ��������

}

// Ű�� �������� ��
void handleKeyrelease(unsigned char key, int x, int y) {
    keyStates[key] = false; //Ű�� ���¸� ����������
}

void keyOperations(void) { //�ǽð����� Ű ���� Ȯ�� / �����̰� �ϴ� �Լ�
    float newX = cameraX;
    float newZ = cameraZ;

    if (keyStates['w']) {
        newX += speed * cos(cameraYaw);
        newZ += speed * sin(cameraYaw);
    }
    if (keyStates['s']) {
        newX -= speed * cos(cameraYaw);
        newZ -= speed * sin(cameraYaw);
    }
    if (keyStates['a']) {
        newX += speed * sin(cameraYaw);
        newZ -= speed * cos(cameraYaw);
    }
    if (keyStates['d']) {
        newX -= speed * sin(cameraYaw);
        newZ += speed * cos(cameraYaw);
    }

    // �����̽��ٸ� ������ ���� ����
    if (keyStates[32] && playerHeight == 0.0f) {
        jumpVelocity = 0.025f; //���� �ӵ� ����
    }

    // ���� ���� ó��
    if (playerHeight > 0.0f || jumpVelocity > 0.0f) {
        playerHeight += jumpVelocity;
        jumpVelocity -= gravity;


        if (playerHeight < 0.0f) {
            playerHeight = 0.0f;
            jumpVelocity = 0.0f;
        }
    }


    if (!isWall(newX, newZ)) {
        cameraX = newX;
        cameraZ = newZ;
    }
    if (checkCameraModelCollision()) {

        item = true; // �̴ϸ� �׸���
    }
    if (checkCameraModelCollision1()) {

        if (speed < 0.03) // �ӵ� �������� 
        {
            speed += 0.02f;
        }

    }
    if (checkCameraModelCollision2()) {

        exit(0);  // ���α׷� ����
    }

    cameraY = playerHeight;
    glutPostRedisplay();
}

void handleMouseMotion(int x, int y) { //���콺 ��� �̺�Ʈ�� ó���ϴ� �Լ�
    static bool wrap = false;
    if (wrap) {
        int centerX = glutGet(GLUT_WINDOW_WIDTH) / 2;
        int centerY = glutGet(GLUT_WINDOW_HEIGHT) / 2;
        int dx = x - centerX;
        int dy = y - centerY;
        const float sensitivity = 0.002f;
        cameraYaw += dx * sensitivity;
        cameraPitch -= dy * sensitivity;
        cameraPitch = std::max(std::min(1.5f, cameraPitch), -1.5f);
        if (dx != 0 || dy != 0) {
            glutWarpPointer(centerX, centerY);
        }
        glutPostRedisplay();
    }
    wrap = !wrap;
}

void setCamera() { // ī�޶� �� ����
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(cameraX, cameraY + 1.0, cameraZ,
        cameraX, cameraY, cameraZ,
        0, 1, 0);
}

void setProjection(int w, int h) { //������ GL_PROJECTION���� 

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    BMPtoTexture();

    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    GLfloat aspectRatio = (GLfloat)w / h;
    gluPerspective(60.0, aspectRatio, 0.1, 100.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, aspectRatio, 0.1, 100.0);


    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}


unsigned char* Read_BmpImage(const char name[], int* width, int* height, int*    //BMP �̹����� �д� �Լ�
    components) {
    FILE* BMPfile; GLubyte garbage;
    long size; int start_point, x;
    GLubyte temp[3]; GLubyte start[4], w[4], h[4];
    unsigned char* read_image;
    BMPfile = fopen(name, "rb");
    for (x = 0; x < 10; x++) { fread(&garbage, 1, 1, BMPfile); }
    fread(&start[0], 1, 4, BMPfile);
    for (x = 0; x < 4; x++) { fread(&garbage, 1, 1, BMPfile); }
    fread(&w[0], 1, 4, BMPfile);
    fread(&h[0], 1, 4, BMPfile);
    (*width) = (w[0] + 256 * w[1] + 256 * 256 * w[2] + 256 * 256 * 256 *
        w[3]);
    (*height) = (h[0] + 256 * h[1] + 256 * 256 * h[2] + 256 * 256 * 256 * h[3]);
    size = (*width) * (*height);
    start_point = (start[0] + 256 * start[1] + 256 * 256 * start[2] + 256 * 1256 *
        256 * start[3]);
    read_image = (unsigned char*)malloc(size * 3);
    for (x = 0; x < (start_point - 26); x++) {
        fread(&garbage, 1, 1, BMPfile);
    }
    for (x = 0; x < (size * 3); x = x + 3) {
        fread(&temp[0], 1, 3, BMPfile);
        read_image[x] = temp[2];
        read_image[x + 1] = temp[1];
        read_image[x + 2] = temp[0];
    }
    fclose(BMPfile);
    return (unsigned char*)read_image;
}



int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(1000, 1000);
    glutCreateWindow("Escape Dessert Maze!!");
    glEnable(GL_DEPTH_TEST);
    LPCWSTR fileName = L"bgm.wav";
    PlaySound(fileName, NULL, SND_FILENAME | SND_ASYNC | SND_LOOP); //��� ���� ���
    ReadModel();
    ReadModel1();
    ReadModel2();
    glutDisplayFunc(drawMaze);
    glutKeyboardFunc(handleKeypress);
    glutKeyboardUpFunc(handleKeyrelease);
    glutPassiveMotionFunc(handleMouseMotion);
    glutReshapeFunc(setProjection);
    glutIdleFunc(keyOperations);
    BMPtoTexture();
    glutMainLoop();
    return 0;

}