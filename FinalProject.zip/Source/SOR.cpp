#include <GL/glut.h>
#include <vector>
#include <iostream>
#include <cmath>
#include <list>
#include <tuple>
#include <fstream>

using namespace std;

#define M_PI 3.14159265358979323 //������ ǥ��

bool SORY = false;
bool SORX = false;

GLsizei winWidth = 800, winHeight = 800; // ȭ�� ũ��

std::vector<std::pair<float, float>> points;
std::list<std::tuple<float, float, float>> rotatedPoints;

int rotatecount = 10; //�ʱ� ȸ�� ���� 10���� ����

float cameraAngle = 0.0f;


void drawSORToFile() { //SOR�� �׸��� ���ÿ� .DAT ���Ϸ� �����ϴ� �Լ�
    std::ofstream file("example_SOR.dat");

    file << "VERTEX = " << rotatedPoints.size() << std::endl;
    for (auto& point : rotatedPoints) {
        float x = std::get<0>(point) * 0.5; //ũ�Ⱑ �ʹ� Ŀ�� ���� ũ��� ����
        float y = std::get<1>(point) * 0.5;
        float z = std::get<2>(point) * 0.5;
        file << x << "\t" << y << "\t" << z << std::endl;
    }

    int groupSize = points.size();
    file << "FACE = " << (groupSize - 1) * 2 * (360 / rotatecount) << std::endl;

    for (int j = 0; j < 360 / rotatecount; j++) {
        for (int i = 0; i < groupSize - 1; ++i) {
            int baseIndex = j * groupSize;
            file << baseIndex + i << "\t"
                << (baseIndex + i + groupSize) % rotatedPoints.size() << "\t"
                << (baseIndex + i + 1) % rotatedPoints.size() << std::endl;
            file << (baseIndex + i + 1) % rotatedPoints.size() << "\t"
                << (baseIndex + i + groupSize) % rotatedPoints.size() << "\t"
                << (baseIndex + i + groupSize + 1) % rotatedPoints.size() << std::endl;
        }
    }
    file.close();
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        //���� ��ġ ���
        float mx = (float)(2.0 * x / winWidth - 1.0);
        float my = (float)(1.0 - 2.0 * y / winHeight);

        points.push_back(std::make_pair(mx, my));

        SORX = false;
        SORY = false;
        glutPostRedisplay();
    }
}

void drawxy() {      // X,Y�� �׸���

    glColor3f(1.0, 1.0, 1.0);
    glPointSize(1.0f);
    glBegin(GL_LINES);
    glVertex3f(0.0, -winWidth, 0.0);
    glVertex3f(0.0, winWidth, 0.0);
    glVertex3f(-winHeight, 0.0, 0.0);
    glVertex3f(winHeight, 0.0, 0.0);
    glEnd();
}

void drawpoint(float x1, float y1, float z1) {

    glBegin(GL_POINTS);
    glVertex3f(x1, y1, z1);
    glBegin(GL_LINES);

}

void drawSOR() {
    rotatedPoints.clear();

    if (points.size() < 2) return;

    int numSteps = 360 / rotatecount;
    float angleIncrement = 2 * M_PI / numSteps;
    glColor3f(0.0, 1.0, 0.0);

    for (int i = 0; i < numSteps; ++i) {
        glBegin(GL_LINES);  // �� ���� �׸��� ���� GL_LINES�� ����մϴ�.

        for (int j = 0; j < points.size(); ++j) {
            float angle = i * angleIncrement;
            float nextAngle = (i + 1) * angleIncrement;

            float x1 = points[j].first * cos(angle);
            float z1 = points[j].first * sin(angle);
            float y1 = points[j].second;

            float x2 = points[j].first * cos(nextAngle);
            float z2 = points[j].first * sin(nextAngle);
            float y2 = points[j].second;

            rotatedPoints.push_back(std::make_tuple(x1, y1, z1));   // ȸ���� �� �߰�


            glVertex3f(x1, y1, z1);
            glVertex3f(x2, y2, z2);

            //ȸ���� ���� ������ ���� ����
            if (j > 0) {
                float x3 = points[j - 1].first * cos(angle);
                float z3 = points[j - 1].first * sin(angle);
                float y3 = points[j - 1].second;

                glVertex3f(x1, y1, z1);
                glVertex3f(x3, y3, z3);


                glVertex3f(x2, y2, z2);
                glVertex3f(x3, y3, z3);

                //�밢�� �� �߰�
                float x4 = points[j - 1].first * cos(nextAngle);
                float z4 = points[j - 1].first * sin(nextAngle);
                float y4 = points[j - 1].second;

                glVertex3f(x1, y1, z1);
                glVertex3f(x4, y4, z4);
            }
        }

        glEnd();
    }

    glutSwapBuffers();
    drawSORToFile();
}
void drawSORX() {

    rotatedPoints.clear();

    if (points.size() < 2) return;

    int numSteps = 360 / rotatecount;
    float angleIncrement = 2 * M_PI / numSteps;
    glColor3f(0.0, 1.0, 0.0);

    for (int i = 0; i < numSteps; ++i) {
        glBegin(GL_LINES);

        for (int j = 0; j < points.size(); ++j) {
            float angle = i * angleIncrement;
            float nextAngle = (i + 1) * angleIncrement;

            float x1 = points[j].first;
            float y1 = points[j].second * cos(angle);
            float z1 = points[j].second * sin(angle);

            float x2 = points[j].first;
            float y2 = points[j].second * cos(nextAngle);
            float z2 = points[j].second * sin(nextAngle);

            rotatedPoints.push_back(std::make_tuple(x1, y1, z1));

            glVertex3f(x1, y1, z1);
            glVertex3f(x2, y2, z2);

            if (j > 0) {
                float x3 = points[j - 1].first;
                float y3 = points[j - 1].second * cos(angle);
                float z3 = points[j - 1].second * sin(angle);

                glVertex3f(x1, y1, z1);
                glVertex3f(x3, y3, z3);

                glVertex3f(x2, y2, z2);
                glVertex3f(x3, y3, z3);

                float x4 = points[j - 1].first;
                float y4 = points[j - 1].second * cos(nextAngle);
                float z4 = points[j - 1].second * sin(nextAngle);

                glVertex3f(x1, y1, z1);
                glVertex3f(x4, y4, z4);
            }
        }
        glEnd();
    }
    glutSwapBuffers();
    drawSORToFile();
}

void clearScreen() {  //ȭ���� �ʱ�ȭ ��Ű�� �Լ�
    points.clear();
    rotatedPoints.clear();
    SORY = false;
    SORX = false;
}

void menu(int option) {  // ȸ����ų ������ ���ϴ� �޴�
    switch (option) {
    case 1:
        rotatecount = 10;
        break;
    case 2:
        rotatecount = 30;
        break;
    case 3:
        rotatecount = 60;
        break;
    case 4:
        rotatecount = 90;
        break;
    case 5:
        clearScreen();
        break;
    default:
        break;
    }
    glutPostRedisplay();
}

void createGLUTMenus() {    // ǥ�õǴ� �޴�
    int submenu = glutCreateMenu(menu);

    glutAddMenuEntry("10", 1);
    glutAddMenuEntry("30", 2);
    glutAddMenuEntry("60", 3);
    glutAddMenuEntry("90", 4);
    glutAddMenuEntry("Clear", 5);
    glutAttachMenu(GLUT_RIGHT_BUTTON);
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 'y' || key == 'Y') {  // Y�� ������ Y�� ���� ȸ��
        SORY = true;
        drawSOR();
        glutPostRedisplay();
    }
    else if (key == 'x' || key == 'X') {  // X�� ������ X�� ���� ȸ��
        SORX = true;
        drawSORX();
        glutPostRedisplay();
    }
    else if (key == 'n' || key == 'N') {  // M�� ������ ī�޶��� ���� ����
        cameraAngle -= 0.1f;
        glutPostRedisplay();
    }
    else if (key == 'm' || key == 'M') {  // N�� ������ ī�޶��� ���� ����
        cameraAngle += 0.1f;
        glutPostRedisplay();
    }
}

void Mydisplay() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glLoadIdentity();
    gluLookAt(0.0, sin(cameraAngle), cos(cameraAngle), 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);  // ī�޶� ������ �ø��� ������ ����
    drawxy();

    glColor3f(1.0, 0.0, 0.0);
    glPointSize(3.0f);
    glBegin(GL_POINTS);
    for (auto& point : points) {
        glVertex3f(point.first, point.second, 0.0);
    }
    glEnd();

    if (SORY) {
        drawSOR();
    }
    if (SORX) {
        drawSORX();
    }
    glFlush();
}

void init(void) {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
}


int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(winWidth, winHeight);
    glutInitWindowPosition(100, 100);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutCreateWindow("SOR Modeler");
    glEnable(GL_DEPTH_TEST);

    init();

    createGLUTMenus();
    glutMouseFunc(mouse);
    glutKeyboardFunc(keyboard);
    glutDisplayFunc(Mydisplay);
    glutMainLoop();
    return 0;
}